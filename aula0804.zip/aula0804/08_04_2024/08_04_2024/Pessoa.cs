﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_04_2024
{
    public class Pessoa
    {
        public string nome;
        public string email;
        public string celular;

        public void cadastrar()
        {
            Console.WriteLine("Digite seu nome: ");
            nome = Console.ReadLine();
            Console.WriteLine("Digite seu E-mail: ");
            email = Console.ReadLine();
            Console.WriteLine("Digite seu número: ");
            celular = Console.ReadLine();
        }

        public void exibir()
        {
            Console.WriteLine("Nome: {0}\nE-mail: {1}\nCelular{2}", this.nome,this.email,this.celular);
        }
    }
}
