﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_04_2024
{
    public class Cliente:Pessoa
    {
        protected int pontos;

        public void mostraPontos()
        {
            Console.WriteLine("Pontos: {0}", this.pontos);
        }

        public void somaPontos(int pontos)
        {
            if (pontos < 1) {
                Console.WriteLine("não foi possivel somar pontos.");
            } else {
                this.pontos = pontos;  
                this.mostraPontos();
            }
            
        }

    }
}
