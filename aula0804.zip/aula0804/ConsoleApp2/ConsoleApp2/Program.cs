﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _08_04_2024;

namespace ConsoleApp2
{
        class Program
    {
        static void Main(string[] args)
        {
            Pessoa p1 = new Pessoa();
            Funcionario funcionario = new Funcionario();
            Cliente cliente = new Cliente();
            funcionario.cadastrar();
            funcionario.exibir();
            cliente.mostraPontos();

        }
    }
}
