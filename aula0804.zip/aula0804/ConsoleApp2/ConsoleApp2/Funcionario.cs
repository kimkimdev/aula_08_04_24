﻿using _08_04_2024;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
     class Funcionario:Pessoa
    {
        
    }
}
